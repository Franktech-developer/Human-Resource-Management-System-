<?php require('session.php');?>
<?php if(logged_in()){ ?>
          <script type="text/javascript">
            window.location = "index.php";
          </script>
    <?php
    } ?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Dandam Sawmill</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>
<?php include('includes/main-topbar.php');?>

<body class="bg-gradient-default">
  <div>
    <!-- Outer Row -->
          <div class="">
            <!-- Nested Row within Card Body -->
            <div class="">
              <div class="col-lg-15 d-none d-lg-block  bg-login-image"></div>
              <div class="">
                <div class="">
                <div>
                <center><h1 class="h4 text-gray-900 mb-4"><font color="green"><b>REA VIPINGO LIMITED</b></font></h1></center>
                  </div>
                  <center><img src="img/rea.jpeg" alt="user" style="width:100%;height:50%;"></center>
            <div class="col-md-15 mb-3">
            <div class="card border-success shadow ">
              
              </div>
            </div>

            <div class="col-md-15 mb-3">
            <div class="card border-success shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div >
                <div class="card">
                    <center><h6 class="card-header"><font color="purple"><b>New Job Opportunities</b></font></h6></center>

                        <p class="card-text" style="padding-left:2%">In search of a job... You can view our vacancies here and apply.. we shall contact you once we scrutinize your details.. </p>
                        <a class="btn btn-sm btn-info " href="pages/admin/newjobs.php">View&nbsp;<i class="fa fa-eye"></i></a>
                    </div><hr>
                    <a class="btn btn-sm btn-secondary " href="pages/admin/recruitlogin.php">My Application Status&nbsp;<i class="fa fa-eye"></i></a>
                  </div>
                </div>
              </div>
            </div>
         
          </div>
          </div>
          </div>
          </div>
          </div>
          </div>
          </div>
          </div>
  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>
  </body>
  <?php include('footer.php');?>
</html>









