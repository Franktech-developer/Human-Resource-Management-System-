
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-info topbar mb-4 static-top shadow">
          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">
               <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle " href="contact.php">   
              <button class="btn btn-success btn-user btn-sm" type="submit" name="btnlogin"><i class="fa fa-phone">&nbsp;Contact Us</i></button>            
               </a>
               
            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle " href="pages/login.php"  role="button" aria-haspopup="true" aria-expanded="false">   
              <button class="btn btn-primary btn-user btn-sm" type="submit" name="btnlogin"><i class="fa fa-user">&nbsp;Sign In</i></button>            
               </a>

            </li>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle " href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">   
              <button class="btn btn-warning btn-user btn-sm" type="submit" name="btnlogin"><i class="fa fa-book">&nbsp;About Us</i></button>            
               </a>

                   <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle " href="help.php"  aria-haspopup="true" aria-expanded="false">   
              <button class="btn btn-warning btn-user btn-sm" type="submit" name="btnlogin"><i class="fa fa-book">&nbsp;Help</i></button>            
               </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <button class="dropdown-item" onclick="on()">            
                  <p class="card-text" style="padding-left:2%"><h5>We are engaged in the cultivation of sisal<br> and production of sisal fibre,<br> manufacture of sisal yams and twiness.</h5> </p>           
                </button>
            </li>


          </ul>

        </nav>
        <!-- End of Topbar -->
          
        <!-- Begin Page Content -->
        <div class="container-fluid">