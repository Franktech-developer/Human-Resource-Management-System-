<div class="side-menu animate-dropdown outer-bottom-xs ">
    <div class="head "><font color="green"><b><h4>Dandam Sawmill</h4></b></font></a></div>
    <nav class="navbar navbar-header navbar-expand-lg">
                <div class="container-fluid">

                    <ul class="navbar-nav topbar-nav ml-md-auto bg-success  navbar-success align-items-center">
                    
                        <li class="nav-item dropdown hidden-caret">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                             <div> <ul>&nbsp;<font color="red"><b>Login </b></font></i></ul></div>
                            </a>
                            <ul class="dropdown-menu notif-box" aria-labelledby="navbarDropdown">
                                <li>
                                <a href="user/customerlogin.php" class="btn btn-primary btn-lg btn-full text-left mt-3 mb-3"><i class="la la-archive"></i> Customer</a>
                                <a href="user/farmerlogin.php" class="btn btn-primary btn-lg btn-full text-left mt-3 mb-3"><i class="la la-archive"></i> Supplier</a>
                                <a href="user/driverlogin.php" class="btn btn-primary btn-lg btn-full text-left mt-3 mb-3"><i class="la la-archive"></i> Driver</a>
                                <a href="user/serviceproviderlogin.php" class="btn btn-primary btn-lg btn-full text-left mt-3 mb-3"><i class="la la-archive"></i> Inventory Manager</a>
                                <a href="user/financeofficerlogin.php" class="btn btn-primary btn-lg btn-full text-left mt-3 mb-3"><i class="la la-archive"></i> Finance Officer</a>
                                <a href="user/shipmentofficerlogin.php" class="btn btn-primary btn-lg btn-full text-left mt-3 mb-3"><i class="la la-archive"></i> Shipment Officer</a>
                                </li>                                       
                                    </div>
                                </li>
                            </ul>
                        </li>

                       

                    </ul>
                    
                </div>
            </nav>
</div>
