      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <hr>
          <div class="card card border-success shadow h-100 py-2 module-body outer-top-xs">
        <ul class="toggle-footer" style="">
            <li class="media">
                <div class="media-body">
             <p> <b>  Contact Us:</b></p>
              <p> <i class="fa fa-map-marker"></i>&nbsp;Nairobi  </p>
              <p> <i class="fa fa-map-marker"></i>&nbsp;Street : Tom Mboya street  </p>
              <p> <i class="fa fa-home"></i>&nbsp;House : Harambee house 5Th floor Rm No c6,c7,c8.  </p>
                    <p><i class="fa fa-phone"></i>&nbsp;02786578 / 0724675487</p>
                   <p><i class="fa fa-envelope"></i>&nbsp;<a href="#">info@reavipingo.ac.ke</a></p>
                </div>
            </li>
    </div>
          <hr>
          <div class="copyright text-center my-auto">
              <span>Copyright © Rea Vipingo 2022</span>
          </div>
        </div>
      </footer>
</body>
</html>

