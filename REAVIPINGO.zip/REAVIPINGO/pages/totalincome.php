<?php

include("adformheader.php");
include("dbconnection.php");
include("includes/connection.php");
$q=mysqli_query($conn,"select * from donations  ");
if(isset($_GET[delid]))
{
	$sql ="DELETE FROM appointment WHERE appointmentid='$_GET[delid]'";
	$qsql=mysqli_query($con,$sql);
	if(mysqli_affected_rows($con) == 1)
	{
		echo "<script>alert('appointment record deleted successfully..');</script>";
	}
}
if(isset($_GET[approveid]))
{
	$sql ="UPDATE patient SET status='Active' WHERE patientid='$_GET[patientid]'";
	$qsql=mysqli_query($con,$sql);
	
	$sql ="UPDATE appointment SET status='Approved' WHERE appointmentid='$_GET[approveid]'";
	$qsql=mysqli_query($con,$sql);
	if(mysqli_affected_rows($con) == 1)
	{
		echo "<script>alert('Appointment record Approved successfully..');</script>";
		echo "<script>window.location='viewappointmentpending.php';</script>";
	}	
}
?><br>
<div class="container-fluid">
<div class="block-header">
        <h2 class="text-center"> ACCOUNT BALANCE</h2>
    </div>

<div class="card bg-success">
	<section class="container"><br>
    <div class="col-lg-12 col-md-3 col-sm-6">
            <div class="info-box-4 hover-zoom-effect">
                <div class="icon"></div>
                <div class="content">
                    <div class="text">Available Amount</div>
                    <div class="number">Ksh 
                        <?php 
              $sql = "SELECT sum(total_pay) as total  FROM `payment`  ";
              $qsql = mysqli_query($con,$sql);
              while ($row = mysqli_fetch_assoc($qsql))
              { 
               echo $row['total'];
             }
              ?>
                    </div>
                </div>
            </div>
        </div>
	</section>
</div>
<div class="container-fluid">

</div>
<center>
  <a href='finance-index.php' class='btn btn-sm btn-raised bg-success'>< Back</a>
</center>
</div>

<?php
include("adformfooter.php");
?>