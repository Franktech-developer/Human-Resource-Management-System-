<?php
include'../includes/connection.php';
include'../includes/employee-sidebar.php';
?><?php 

                $query = 'SELECT ID, t.TYPE
                          FROM users u
                          JOIN type t ON t.TYPE_ID=u.TYPE_ID WHERE ID = '.$_SESSION['MEMBER_ID'].'';
                $result = mysqli_query($db, $query) or die (mysqli_error($db));
      
                while ($row = mysqli_fetch_assoc($result)) {
                          $Aa = $row['TYPE'];
                   
if ($Aa=='User'){  }
                         
           
}   
            ?> <div class="">
            <h5><font color="black">Employee Panel: </font></h5><hr>
            <a >
                <span class=" text-gray-800 small"><?php echo  $_SESSION['FIRST_NAME']. ' '.$_SESSION['LAST_NAME'] ;?></span>
               </a>
               </div>
          <div class="row show-grid">
                    
          <!-- PRODUCTS ROW -->
            <!-- Product record -->
         
          <!-- Customer ROW -->
            <!-- Supplier record -->
            <div class="col-md-12 mb-3">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-0">
                      <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Departments</div>
                      <div class="h6 mb-0 font-weight-bold text-gray-800">
                        <?php 
                        $query = "SELECT COUNT(*) FROM department";
                        $result = mysqli_query($db, $query) or die(mysqli_error($db));
                        while ($row = mysqli_fetch_array($result)) {
                            echo "$row[0]";
                          }
                        ?> Record(s)
                      </div><hr>
                          <a href="department.php"><i class="fa fa-eye">View&nbsp;&nbsp;</i></a>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-building fa-2x " style="color:red"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
               <!-- Customer ROW -->
            <!-- Supplier record -->
            <div class="col-md-12 mb-3">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-0">
                      <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">My Attendance</div>
                      <div class="h6 mb-0 font-weight-bold text-gray-800">
                        <?php 
                        $query = "SELECT COUNT(*) FROM logs where LOGID='".$_SESSION['MEMBER_ID']."'";
                        $result = mysqli_query($db, $query) or die(mysqli_error($db));
                        while ($row = mysqli_fetch_array($result)) {
                            echo "$row[0]";
                          }
                        ?> Record(s)
                      </div><hr>
                          <a href="attendance.php"><i class="fa fa-eye">View&nbsp;&nbsp;</i></a>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-sign-in-alt fa-2x " style="color:yellow"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Employee ROW -->
            <!-- Employee record -->
            <div class="col-md-12 mb-3">
              <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-0">
                      <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Notifications</div>
                      <div class="h6 mb-0 font-weight-bold text-gray-800">
                        <?php 
                        $query = "SELECT COUNT(*) FROM notice where receiver='employess' ";
                        $result = mysqli_query($db, $query) or die(mysqli_error($db));
                        while ($row = mysqli_fetch_array($result)) {
                            echo "$row[0]";
                          }
                        ?> Record(s)
                      </div><hr>
                          <a href="admin/employeenotifications.php"><i class="fa fa-eye">View&nbsp;&nbsp;</i></a>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-bell fa-2x " style="color:green"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- User record -->
            </div>
            
                        <!-- /.panel-body -->
                    </div></div></div></div></div></div>
          <!-- 
          <div class="col-md-3">
           <div class="col-md-12 mb-2">
              <div class="card border-left-danger shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-danger text-uppercase mb-1"><i class="fas fa-list text-danger">&nbsp;&nbsp;&nbsp;</i>Recent Products</div>
                      <div class="h6 mb-0 font-weight-bold text-gray-800">
                        <?php 
                          $query = "SELECT NAME FROM product order by PRODUCT_ID DESC LIMIT 10";
                          $result = mysqli_query($db, $query) or die(mysqli_error($db));
                          while ($row = mysqli_fetch_array($result)) {
                              echo "<ul style='list-style-position: outside'>";
                              echo "<li>$row[0]</li>";
                              echo "</ul>";
                            }
                          ?>
                      </div>
                    </div>
                    <div class="col-auto">
                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
            </div> -->
            

          </div>

<?php
include'../includes/footer.php';
?>