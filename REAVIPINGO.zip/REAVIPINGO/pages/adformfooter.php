</section>
<div class="color-bg"></div>
<script src="assets2/bundles/libscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js -->
<script src="assets2/bundles/morphingsearchscripts.bundle.js"></script> <!-- morphing search Js --> 
<script src="assets2/bundles/vendorscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js --> 

<script src="assets2/bundles/datatablescripts.bundle.js"></script><!-- Jquery DataTable Plugin Js -->

<script src="assets2/bundles/mainscripts.bundle.js"></script><!-- Custom Js -->
<script src="assets2/bundles/morphingscripts.bundle.js"></script><!-- morphing search page js --> 
<script src="assets2/js/morphing.js"></script><!-- Custom Js -->  
<script src="assets2/js/pages/tables/jquery-datatable.js"></script>
<script src="assets2/js/pages/forms/editors.js"></script>




</body>
</body>
</html>