</section>
<div></div>

<!-- Jquery Core Js --> 
<script src="assets2/bundles/libscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js -->
<script src="assets2/bundles/morphingsearchscripts.bundle.js"></script> <!-- morphing search Js --> 
<script src="assets2/bundles/vendorscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js --> 
<script src="assets2/bundles/datatablescripts.bundle.js"></script><!-- Jquery DataTable Plugin Js -->

<script src="assets2/plugins/jquery-sparkline/jquery.sparkline.min.js"></script> <!-- Sparkline Plugin Js -->
<script src="assets2/plugins/chartjs/Chart.bundle.min.js"></script> <!-- Chart Plugins Js --> 
 


<script src="assets2/bundles/mainscripts.bundle.js"></script><!-- Custom Js -->
<script src="assets2/bundles/morphingscripts.bundle.js"></script><!-- morphing search page js --> 
<script src="assets2/js/morphing.js"></script><!-- Custom Js -->  
<script src="sweetalert2.min.js"></script>
<script src="assets2/js/pages/index.js"></script>
<script src="assets2/js/pages/charts/sparkline.min.js"></script>
<script src="assets2/js/pages/tables/jquery-datatable.js"></script>




</body>
</body>
</html>