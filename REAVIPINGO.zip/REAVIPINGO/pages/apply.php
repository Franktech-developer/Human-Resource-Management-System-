<?php
include('connection.php');
include('config.php');
include'connection.php';
include'../includes/connection.php';
include'../includes/employee-sidebar.php';
$q1=mysqli_query($conn,"select * from users where ID='".$_SESSION['MEMBER_ID']."'");
$r1=mysqli_fetch_assoc($q1);

error_reporting(0);
include('config.php');
if(isset($_POST['submit']))
  {
$fullnames=$_POST['fullnames'];
$department=$_POST['department'];
$phone=$_POST['phone'];
$LOGID=$_POST['LOGID'];
$date=$_POST['date'];

$comment=Signed;

$sql = "SELECT * FROM logs WHERE date=:date";
$query = $dbh->prepare($sql);
$query->bindParam(':date',$date,PDO::PARAM_STR);
$query-> execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0){

    $msg="You Have already Signed Attentance For This Day";
}

else{
$sql="INSERT INTO logs(fullnames,department,phone,LOGID,date,cdate,comment) VALUES(:fullnames,:department,:phone,:LOGID,:date,current_timestamp,:comment)";
$query = $dbh->prepare($sql);
$query->bindParam(':fullnames',$fullnames,PDO::PARAM_STR);
$query->bindParam(':department',$department,PDO::PARAM_STR);
$query->bindParam(':phone',$phone,PDO::PARAM_STR);
$query->bindParam(':LOGID',$LOGID,PDO::PARAM_STR);
$query->bindParam(':date',$date,PDO::PARAM_STR);

$query->bindParam(':comment',$comment,PDO::PARAM_STR);


$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$msg="Attendance Successful Signed";
}
else
{
$error="Something went wrong. Please try again";
}

}
  }

?>


<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Rea Vipingo Ltd</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/modern-business.css" rel="stylesheet">
    <style>
    .navbar-toggler {
        z-index: 1;
    }

    @media (max-width: 576px) {
        nav > .container {
            width: 100%;
        }
    }
    </style>
        <style>
    .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
    </style>


</head>

<body>
    <!-- Page Content -->
    <div class="container">
        <!-- Page Heading/Breadcrumbs -->
        <center><h5 class="mt-4 mb-3">Employee Attentance</h5></center>

        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="employee-index.php">Back</a>
            </li>
        </ol>
            <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php }
        else if($msg){?><div class="succWrap"><strong>MESSAGE</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
        <!-- Content Row -->
        <form name="donar" method="post">
<div class="card">
<div class="col-lg-4 mb-4">

<div><input type="hidden" name="fullnames"  value="<?php  echo $r1['fullnames'];  ?>" class="form-control" required></div>
</div>

<div class="col-lg-4 mb-4">

<div><input type="hidden" name="department"  value="<?php  echo $r1['department'];  ?>" class="form-control" required></div>
</div>

<div class="col-lg-4 mb-4">

<div><input type="hidden" name="phone" class="form-control" value="<?php  echo $r1['phone'];  ?>" required minlength="10"></div>
</div>
<div class="col-lg-4 mb-4">

<div><input type="hidden" name="LOGID" value="<?php  echo $r1['EMPLOYEE_ID'];  ?>"class="form-control"></div>
</div>

<div class="col-lg-12 mb-4">
<div class="font-italic">Date</div>
<div><input type="date" name="date" value="<?php echo date('Y-m-d'); ?>" readonly="true" class="form-control"></div><br>
<div><input type="submit" name="submit" class="btn btn-primary" value="submit" style="cursor:pointer"></div>
</div>






</div>


<div class="row">
<div class="col-lg-4 mb-4">


<div>

<div class="row">
<div class="col-lg-4 mb-4">

</div>



</div>



        <!-- /.row -->
</form>
        <!-- /.row -->
</div>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/tether/tether.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

</body>

</html>
