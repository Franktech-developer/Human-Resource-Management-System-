<?php
session_start();
include('includes/connection.php');

$q=mysqli_query($conn,"select * from application where email='".$_SESSION['alogin']."'   ");
$rr=mysqli_num_rows($q);
if(!$rr)
{
echo "<h2 style='color:green'>You Have No New Notifications !!!</h2>";
}
else
{
?>
<script>
	function DeleteGrop(id)
	{
		if(confirm("You want to delete this Group ?"))
		{
		window.location.href="delete_group.php?id="+id;
		}
	}
</script>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>bmc</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body>
      <!------MENU SECTION START-->

<!-- MENU SECTION END-->
    <div class="content-wrapper">
         <div class="container">
         <section class="content-header">
     <ol class="breadcrumb">
        <li class="active"></li>
      </ol>
    </section>
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line"><font color="green">Application Status</font></h4>

                            </div>

        </div>


        <table class="table ">
	<Tr class="active">
	<th>#</th>
	<th>Applicant Names</th>
	<th>Remarks</th>
	</Tr>
		<?php
$i=1;
while($row=mysqli_fetch_assoc($q))
{

echo "<Tr>";
echo "<td>".$i."</td>";


echo "<td>".$row['fullnames']."</td>";
echo "<td>".$row['status']."</td>";


?>



<!--<Td><a href="index.php?page=update_group" style='color:green'><span class='glyphicon glyphicon-edit'></span></a></td>-->

<?php
echo "</Tr>";
$i++;
}
		?>

</table>
<?php }?>