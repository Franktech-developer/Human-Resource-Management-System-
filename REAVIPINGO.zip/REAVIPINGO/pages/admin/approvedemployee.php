<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{ 

// code for block student    
if(isset($_GET['inEMPLOYEE_ID']))
{
$EMPLOYEE_ID=$_GET['inEMPLOYEE_ID'];
$STATUS=Pending;
$sql = "update employee set STATUS=:STATUS  WHERE EMPLOYEE_ID=:EMPLOYEE_ID";
$query = $dbh->prepare($sql);
$query -> bindParam(':EMPLOYEE_ID',$EMPLOYEE_ID, PDO::PARAM_STR);
$query -> bindParam(':STATUS',$STATUS, PDO::PARAM_STR);
$query -> execute();
header('location:approvedemployee.php');
}



//code for active students
if(isset($_GET['EMPLOYEE_ID']))
{
$EMPLOYEE_ID=$_GET['EMPLOYEE_ID'];
$STATUS=Approved;
$sql = "update employee set STATUS=:STATUS  WHERE EMPLOYEE_ID=:EMPLOYEE_ID";
$query = $dbh->prepare($sql);
$query -> bindParam(':EMPLOYEE_ID',$EMPLOYEE_ID, PDO::PARAM_STR);
$query -> bindParam(':STATUS',$STATUS, PDO::PARAM_STR);
$query -> execute();
header('location:approvedemployee.php');
}


    ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>REA</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- DATATABLE STYLE  -->
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body>
      <!------MENU SECTION START-->

<!-- MENU SECTION END-->
    <div class="content-wrapper">
         <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 > <font color="purple">APPROVED EMPLOYEE LIST:</font></h4>
                  
    </div>
  
        </div>
            <div class="row">
                <div class="col-md-12">
           
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                          
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th><font color="green">Employee ID</font></th>
                                            <th><font color="green">Firts Name</font></th>
                                            <th><font color="green">Last Name</font></th>
                                            <th><font color="green">Gender</font></th> 
                                            <th><font color="green">Email</font></th>  
                                            <th><font color="green">Phone Number</font></th>   
                                            <th><font color="green">Job ID</font></th>   
                                            <th><font color="green">Hired Date</font></th>                                                                                                                                                                                      
                                            <th><font color="blue">STATUS</font></th>
                                            <th><font color="blue">Action</font></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
<?php $sql = "SELECT * from employee where JOB_ID='2' and STATUS='Approved'";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{               ?>                                      
                                        <tr class="odd gradeX">
                                            <td class="center"><?php echo htmlentities($cnt);?></td>                                     
                                            <td class="center"><?php echo htmlentities($result->EMPLOYEE_ID);?></td>
                                            <td class="center"><?php echo htmlentities($result->FIRST_NAME);?></td>
                                            <td class="center"><?php echo htmlentities($result->LAST_NAME);?></td>
                                            <td class="center"><?php echo htmlentities($result->GENDER);?></td>   
                                            <td class="center"><?php echo htmlentities($result->EMAIL);?></td>     
                                            <td class="center"><?php echo htmlentities($result->PHONE_NUMBER);?></td>  
                                            <td class="center"><?php echo htmlentities($result->JOB_ID);?></td>   
                                            <td class="center"><?php echo htmlentities($result->HIRED_DATE);?></td>                                                                 
                                            <td style="background-color:yellow;"class="center"><?php if($result->STATUS==Pending)
                                            {
                                                echo htmlentities("Pending");
                                            } else {


                                            echo htmlentities("Approved");
}
                                            ?></td>
                                            <td class="center">
<?php if($result->STATUS==Approved)
 {?>
<a href="approvedemployee.php?inEMPLOYEE_ID=<?php echo htmlentities($result->EMPLOYEE_ID);?>"  >  <button class="btn btn-danger btn-sm"> Deactivate</button>
<?php } else {?>

                                            <a href="approvedemployee.php?EMPLOYEE_ID=<?php echo htmlentities($result->EMPLOYEE_ID);?>" ><button class="btn btn-primary btn-sm"> Activate</button> 
                                            <?php } ?>
                                          
                                            </td>
                                        </tr>
 <?php $cnt=$cnt+1;}} ?>                                      
                                    </tbody>
                                </table>
                                <div>
                <a href="dashboard.php"  >  <button class="btn btn-info btn-sm"> Back</button>
</div>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>


            
    </div>
    <div class="col-md-12">

    </div>
    </div>
    
     <!-- CONTENT-WRAPPER SECTION END-->
 
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- DATATABLE SCRIPTS  -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
    
</body>

</html>
<?php } ?>
