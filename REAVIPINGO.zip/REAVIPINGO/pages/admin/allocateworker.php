<?php
include('includes/connection.php');
session_start();

$q1=mysqli_query($conn,'select * from application where email="'.$_SESSION['alogin'].'"');
$r1=mysqli_fetch_assoc($q1);

error_reporting(0);
include('includes/config.php');
if(isset($_POST['submit']))
  {


$beneficiary_name=$_POST['beneficiary_name'];
$email=$_POST['email'];


$sql="UPDATE application set staff_allocated='$email' where beneficiary_name='$beneficiary_name' ";
$query = $dbh->prepare($sql);
$query->bindParam(':beneficiary_name',$beneficiary_name,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);


$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$msg="Your Application Has Been Received Successfully.... Our Team is working on it.. please click on status to see if your child has been selected.. Thank you For Choosing BMC.. WE VALUE YOUR FUTURE";
}
else 
{
$msg="Allocation Successfull";
}


  }

?>


<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BMC</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/modern-business.css" rel="stylesheet">
    <style>
    .navbar-toggler {
        z-index: 1;
    }
    
    @media (max-width: 576px) {
        nav > .container {
            width: 100%;
        }
    }
    </style>
        <style>
    .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
    </style>


</head>

<body>

<?php include('Guardian/includes/header.php');?>

    <!-- Page Content -->
    <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <h5 class="mt-4 mb-3">Allocate</h5>

        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="Guardian/index.php">Home</a>
            </li>
        </ol>
            <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
        else if($msg){?><div class="succWrap"><strong>MESSAGE</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
        <!-- Content Row -->
        <form name="donar" method="post">


<div class="form-group">
<label>Beneficiary Names</label>

                              <select name="beneficiary_name" onchange="showLoanDetails(this.value)" class="form-control" required>
                              <option value="">Select Beneficiary</option>
                              <?php
                              $q1=mysqli_query($conn,"SELECT * from application  where  status='approved' and staff_allocated='NotAllocated' ");
                              while($r1=mysqli_fetch_assoc($q1))
                              {
                              echo "<option value='".$r1['beneficiary_name']."'>".$r1['beneficiary_name']."</option>";
                              }
                              ?>
                              </select>
                              </div>

                              <div class="form-group">
<label>Social Worker</label>

                              <select name="email" onchange="showLoanDetails(this.value)" class="form-control" required>
                              <option value="">Select Social Worker</option>
                              <?php
                              $q1=mysqli_query($conn,"SELECT * from staff  where position='social worker' and  status='approved' ");
                              while($r1=mysqli_fetch_assoc($q1))
                              {
                              echo "<option value='".$r1['email']."'>".$r1['email']."</option>";
                              }
                              ?>
                              </select>
                              </div>
                              <div class="form-group">
                                  <input type="submit" name="submit" value="Allocate Worker" class="btn btn-info pull-right">



          </div>



</div>



        <!-- /.row -->
</form>   
        <!-- /.row -->
</div>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/tether/tether.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

</body>

</html>
