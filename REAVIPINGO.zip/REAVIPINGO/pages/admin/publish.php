<?php

include('connection.php');
if(isset($_GET["publish"])){

            $id=$_GET["publish"];
            $sql=mysqli_query($conn,"update jobs set status ='vailble' where id = '$id'");
            if (!$sql) {
                die (mysqli_error($conn));
                }

else {
$err= "request Received successfully... ";
include"manage-vacancy.php";
exit();
}

    }




    ?>
