<?php

include('includes/connection.php');
if(isset($_GET["accept"])){

            $request_id=$_GET["accept"];
            $sql=mysqli_query($conn,"update request set status ='Received' where request_id = '$request_id'");
            if (!$sql) {
                die (mysqli_error($conn));
                }

else {
$err= "request Received successfully... ";
include"beneficiaryrequests.php";
exit();
}

    }




    ?>
