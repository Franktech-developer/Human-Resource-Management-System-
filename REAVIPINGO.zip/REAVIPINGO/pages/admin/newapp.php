<?php

include('includes/connection.php');
if(isset($_GET["accept"])){

            $id=$_GET["accept"];
            $sql=mysqli_query($conn,"update application set status ='YouHaveBeenShortlisted' where id = '$id'");
            if (!$sql) {
                die (mysqli_error($conn));
                }

else {
$err= "request Received successfully... ";
include"newapplications.php";
exit();
}

    }




    ?>
