<?php

include('includes/connection.php');
if(isset($_GET["accept"])){

            $id=$_GET["accept"];
            $sql=mysqli_query($conn,"update notice set status ='read' where id = '$id'");
            if (!$sql) {
                die (mysqli_error($conn));
                }

else {
$err= " successfully... ";
include"beneficiarynotifications.php";
exit();
}

    }




    ?>
