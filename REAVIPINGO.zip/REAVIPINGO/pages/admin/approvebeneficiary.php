<?php

include('includes/connection.php');
if(isset($_GET["accept"])){

            $application_id=$_GET["accept"];
            $sql=mysqli_query($conn,"update application set status ='Approved',reason='beneficiary accepted' where application_id = '$application_id'");
            if (!$sql) {
                die (mysqli_error($conn));
                }

else {
$err= "request Received successfully... ";
include"beneficiary.php";
exit();
}

    }




    ?>
