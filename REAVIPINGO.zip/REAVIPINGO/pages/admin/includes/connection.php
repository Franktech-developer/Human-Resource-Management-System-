<?php
$conn=mysqli_connect("localhost","root","","rea");
?>
