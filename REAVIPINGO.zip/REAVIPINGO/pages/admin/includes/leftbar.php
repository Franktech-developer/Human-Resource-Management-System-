	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				
				<li><a href="dashboard.php"><h4> <i class="fa fa-home"></i>HOME</h4></a></li><hr>
			

<ul>

<center><li><font color="orange"><b>EMPLOYEES</b></font></li></center>
<li><a href="pendingemployee.php"><i class="fa fa-users"></i> Pending Employees</a></li>
<li><a href="approvedemployee.php"><i class="fa fa-users"></i> Approved Employees</a></li>
<center><li><font color="orange"><b>STAFFS</b></font></li></center>
<li><a href="pendingstaff.php"><i class="fa fa-users"></i> Pending Staffs</a></li>
<li><a href="approvedstaff.php"><i class="fa fa-users"></i> Approved Staffs</a></li>
<center><li><font color="orange"><b>ADD USERS</b></font></li></center>
<li><a href="add-user.php"><i class="fa fa-users"></i> Add  New User</a></li>
<center><li><font color="orange"><b>MESSAGES</b></font></li></center>
<li><a href="manage-conactusquery.php"><i class="fa fa-envelope"></i> Manage Messages</a></li>


			</ul>
		</nav>