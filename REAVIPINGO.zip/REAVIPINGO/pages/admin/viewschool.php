<?php
include('includes/connection.php');

$q=mysqli_query($conn,"select * from employees where leavee='Allocated'  ");
$rr=mysqli_num_rows($q);
if(!$rr)
{
echo "<h2 style='color:green'> No Records  Found !!!</h2>";
}
else
{
?>
<script>
	function DeleteGrop(id)
	{
		if(confirm("You want to delete this Group ?"))
		{
		window.location.href="delete_group.php?id="+id;
		}
	}
</script>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>bmc</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body>
      <!------MENU SECTION START-->

<!-- MENU SECTION END-->
    <div class="content-wrapper">
         <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line"><font color="green"> Employees Leave Allowances</font></h4>

                            </div>

        </div>


        <table class="table ">
	<tr>






		</td>
	</tr>
	<Tr class="active">
		<th>#</th>
		<th>Full Names</th>
		<th> Amount Per Day</th>
	<th>Days</th>


	<th>Total Amount</th>
    <th>Allowance Status</th>
    <th>Action</th>
		
		<!--<th>Update</th>-->
	</Tr>
		<?php


$i=1;
while($row=mysqli_fetch_assoc($q))
{

echo "<Tr>";
echo "<td>".$i."</td>";

echo "<td>".$row['fullnames']."</td>";
echo "<td>".$row['amount']."</td>";
echo "<td>".$row['days']."</td>";
echo "<td>".$row['totalamount']."</td>";
echo "<td>".$row['leaveestatus']."</td>";
?>

<Td><a href="confirmm.php?accept=<?php echo $row['id'];?>"
</i>Approve </a>

<!--<Td><a href="index.php?page=update_group" style='color:green'><span class='glyphicon glyphicon-edit'></span></a></td>-->

<?php
echo "</Tr>";
$i++;
}
		?>

</table>
<?php }?>
