<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{ 

// code for block student    
if(isset($_GET['inguardian_id']))
{
$guardian_id=$_GET['inguardian_id'];
$Status=pending;
$sql = "update guardian set status=:status  WHERE guardian_id=:guardian_id";
$query = $dbh->prepare($sql);
$query -> bindParam(':guardian_id',$guardian_id, PDO::PARAM_STR);
$query -> bindParam(':status',$Status, PDO::PARAM_STR);
$query -> execute();
header('location:guardian.php');
}



//code for active students
if(isset($_GET['guardian_id']))
{
$guardian_id=$_GET['guardian_id'];
$Status=approved;
$sql = "update guardian set status=:status  WHERE guardian_id=:guardian_id";
$query = $dbh->prepare($sql);
$query -> bindParam(':guardian_id',$guardian_id, PDO::PARAM_STR);
$query -> bindParam(':status',$Status, PDO::PARAM_STR);
$query -> execute();
header('location:guardian.php');
}


    ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="wguardian_idth=device-wguardian_idth, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>BMC| Manage users</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- DATATABLE STYLE  -->
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body>
      <!------MENU SECTION START-->

<!-- MENU SECTION END-->
    <div class="content-wrapper">
         <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 > <font color="purple">Manage Employees</font></h4>
                  
    </div>
  
        </div>
            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                          
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" guardian_id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th><font color="green">Full Names</font></th>
                                            <th><font color="green">Id/Passport Number</font></th>
                                            <th><font color="green">Department</font></th>
                                      
                                        
                                            <th><font color="green">Phone</font></th>  
                                            <th><font color="green">Email</font></th>   
                                            <th><font color="blue">Status</font></th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php $sql = "SELECT * from employees";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{               ?>                                      
                                        <tr class="odd gradeX">
                                            <td class="center"><?php echo htmlentities($cnt);?></td>                                     
                                            <td class="center"><?php echo htmlentities($result->fullnames);?></td>
                                            <td class="center"><?php echo htmlentities($result->idno);?></td>
                                            <td class="center"><?php echo htmlentities($result->department);?></td>
                                          
                                            <td class="center"><?php echo htmlentities($result->phone);?></td>     
                                            <td class="center"><?php echo htmlentities($result->email);?></td> 
                                            <td class="center"><?php echo htmlentities($result->STATUS);?></td>                                                                    
                                            
                                           
                                          
                                            </td>
                                        </tr>
 <?php $cnt=$cnt+1;}} ?>                                      
                                    </tbody>
                                </table>
                                <div>
                <a href="dashboard.php"  >  <button class="btn btn-info btn-sm"> Back</button>
</div>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>


            
    </div>
    <div class="col-md-12">

    </div>
    </div>
    
     <!-- CONTENT-WRAPPER SECTION END-->
 
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- DATATABLE SCRIPTS  -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
    
</body>

</html>
<?php } ?>
