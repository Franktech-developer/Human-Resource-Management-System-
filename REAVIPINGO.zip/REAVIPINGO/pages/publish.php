<?php

include('connection.php');
if(isset($_GET["accept"])){

            $id=$_GET["accept"];
            $sql=mysqli_query($conn,"update jobs set status ='vailble' where id = '$id'");
            if (!$sql) {
                die (mysqli_error($conn));
                }

else {
$err= "Job Updated successfully... ";
include"manage-vacancy.php";
exit();
}

    }




    ?>
