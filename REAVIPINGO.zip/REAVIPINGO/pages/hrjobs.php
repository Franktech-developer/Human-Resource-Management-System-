<?php
include('connection.php');
session_start();

$q1=mysqli_query($conn,'select * from employees where email="'.$_SESSION['MEMBER_ID'].'"');
$r1=mysqli_fetch_assoc($q1);

error_reporting(0);
include('config.php');
if(isset($_POST['submit']))
  {
$jobname=$_POST['jobname'];
$description=$_POST['description'];
$status=Available;



$sql="INSERT INTO jobs(jobname,description,status) VALUES(:jobname,:description,:status)";
$query = $dbh->prepare($sql);

$query->bindParam(':jobname',$jobname,PDO::PARAM_STR);
$query->bindParam(':description',$description,PDO::PARAM_STR);
$query->bindParam(':status',$status,PDO::PARAM_STR);

$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$msg="Job Added Successfully.... ";
}
else
{
$error="Something went wrong. Please try again";
}


  }

?>


<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Rea Vipingo Ltd</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/modern-business.css" rel="stylesheet">
    <style>
    .navbar-toggler {
        z-index: 1;
    }

    @media (max-width: 576px) {
        nav > .container {
            width: 100%;
        }
    }
    </style>
        <style>
    .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
    </style>


</head>

<body>

    <!-- Page Content -->
    <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <h5 class="mt-4 mb-3">Add New Job Vaccancy</h5>

        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="hr-index.php">Back</a>
            </li>
        </ol>
            <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php }
        else if($msg){?><div class="succWrap"><strong>MESSAGE</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
        <!-- Content Row -->
        <form name="donar" method="post">

<div class="card" style="background-color:#B2BEB5">
<div class="col-lg-12 mb-4">
<div class="font-bold">Job Title</div>
<div><input type="text" class="form-control" name="jobname"></textarea></div>
</div>

<div class="col-lg-12 mb-4">
<div class="font-Bold">Job Description,Qualifications and Requirements</div>
<div><textarea rows="10" class="form-control" name="description"></textarea></div>
</div>
<div >
<div class="col-lg-12 mb-4">
<div><input type="submit" name="submit" class="btn btn-primary" value="submit" style="cursor:pointer"></div>
</div>




        <!-- /.row -->
</form>
        <!-- /.row -->
</div>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/tether/tether.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

</body>

</html>
