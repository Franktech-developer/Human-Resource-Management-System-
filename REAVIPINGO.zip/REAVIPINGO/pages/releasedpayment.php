<?php
session_start();
error_reporting(0);
include('config.php');
if(strlen($_SESSION['MEMBER_ID'])==0)
    {   
header('location:finance-index.php');
}
else{ 

// code for block student    
if(isset($_GET['inpay_no']))
{
$pay_no=$_GET['inpay_no'];
$status=Released;
$sql = "update payment set status=:status  WHERE pay_no=:pay_no";
$query = $dbh->prepare($sql);
$query -> bindParam(':pay_no',$pay_no, PDO::PARAM_STR);
$query -> bindParam(':status',$status, PDO::PARAM_STR);
$query -> execute();
header('location:approvepayment.php');
}



//code for active students
if(isset($_GET['pay_no']))
{
$pay_no=$_GET['pay_no'];
$status=Approved;
$sql = "update payment set status=:status  WHERE pay_no=:pay_no";
$query = $dbh->prepare($sql);
$query -> bindParam(':pay_no',$pay_no, PDO::PARAM_STR);
$query -> bindParam(':status',$status, PDO::PARAM_STR);
$query -> execute();
header('location:approvepayment.php');
}


    ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Rea Vipingo Ltd</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- DATATABLE STYLE  -->
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body>
      <!------MENU SECTION START-->

<!-- MENU SECTION END-->
    <div class="content-wrapper">
         <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 > <font color="green">RELEASED PAYMENTS.</font></h4>
        </div>
        <a href="finance-index.php" class="btn btn-sm btn-default"><i class="fa fa-arrow-left">Back</i></a><hr>
        
            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                          
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th><font color="green">Payment Id</font></th> 
                                            <th><font color="green">Employee Id</font></th> 
                                            <th><font color="green">First Name</font></th>
                                            <th><font color="green">Last Name</font></th>
                                            <th><font color="green">Nssf</font></th>
                                            <th><font color="green">Basic Salary</font></th>
                                            <th><font color="green">Transport</font></th>
                                            <th><font color="green">Account Number</font></th>
                                            <th><font color="green">Year</font></th>
                                            <th><font color="green">Month</font></th>
                                            <th><font color="green">Absence</font></th>
                                            <th><font color="green">Date</font></th>
                                            <th><font color="green">Overtime</font></th>
                                            <th><font color="green">Medical Allowance</font></th>
                                            <th><font color="green">House Allowance</font></th>
                                            <th><font color="green">Total Payment</font></th>
                                            <th><font color="green">Status</font></th>
                                            <th><font color="green">Action</font></th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php $sql = "SELECT * from payment where status='Released'";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{               ?>                                      
                                        <tr class="odd gradeX">
                                            <td class="center"><?php echo htmlentities($cnt);?></td>                                     
                                            <td class="center"><?php echo htmlentities($result->pay_no);?></td> 
                                            <td class="center"><?php echo htmlentities($result->emp_id);?></td>    
                                            <td class="center"><?php echo htmlentities($result->name);?></td>
                                            <td class="center"><?php echo htmlentities($result->lname);?></td>    
                                            <td class="center"><?php echo htmlentities($result->nssf);?></td>  
                                            <td class="center"><?php echo htmlentities($result->basic);?></td>                
                                            <td class="center"><?php echo htmlentities($result->trans_allow);?></td>                
                                            <td class="center"><?php echo htmlentities($result->accno);?></td>                
                                            <td class="center"><?php echo htmlentities($result->year);?></td>                
                                            <td class="center"><?php echo htmlentities($result->month);?></td>                
                                            <td class="center"><?php echo htmlentities($result->absence)*500;?></td>  
                                            <td class="center"><?php echo htmlentities($result->date);?></td>                
                                            <td class="center"><?php echo htmlentities($result->overtime)*600;?></td>                
                                            <td class="center"><?php echo htmlentities($result->medi_allow);?></td>                
                                            <td class="center"><?php echo htmlentities($result->house_allow);?></td>                
                                            <td class="center"><?php echo htmlentities($result->total_pay);?></td>                                                        
                                            <td style="background-color:yellow;"class="center"><?php if($result->status=='')
                                            {
                                                echo htmlentities("Pending");
                                            } else {


                                            echo htmlentities("Released");
}
                                            ?></td>
                                            <td class="center">
<?php if($result->status=='')
 {?>
<a href="approvepayment.php?inpay_no=<?php echo htmlentities($result->pay_no);?>"  >  <button class="btn btn-danger btn-sm">Release Payment</button>
<?php } else {?>  <?php } ?>
                                          
                                            </td>
                                        </tr>
 <?php $cnt=$cnt+1;}} ?>                                      
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>


            
    </div>
    <div class="col-md-12">

    </div>
    </div>
    
     <!-- CONTENT-WRAPPER SECTION END-->
 
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- DATATABLE SCRIPTS  -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
    
</body>

</html>
<?php } ?>
