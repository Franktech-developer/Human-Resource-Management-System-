<?php
include('connection.php');
session_start();

$q1=mysqli_query($conn,'select * from users where ID="'.$_SESSION['MEMBER_ID'].'" ');
$r1=mysqli_fetch_assoc($q1);

error_reporting(0);
include('config.php');
if(isset($_POST['submit']))
  {
$leavedescription=$_POST['leavedescription'];
$days=$_POST['days'];
$startingdate=$_POST['startingdate'];
$leaveestatus=Pending;



$sql="UPDATE employee set leavedescription='$leavedescription',days='$days',startingdate='$startingdate',leaveestatusstatus='$leaveestatus' where ID='$ID'";
$query = $dbh->prepare($sql);
$query->bindParam(':leavedescription',$leavedescription,PDO::PARAM_STR);
$query->bindParam(':days',$days,PDO::PARAM_STR);
$query->bindParam(':startingdate',$startingdate,PDO::PARAM_STR);
$query->bindParam(':leaveestatus',$leaveestatus,PDO::PARAM_STR);

$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$msg=" Notification send Successfully.... ";
}
else 
{
$msg="Leave Added Successfully";
}


  }

?>


<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BMC</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/modern-business.css" rel="stylesheet">
    <style>
    .navbar-toggler {
        z-index: 1;
    }
    
    @media (max-width: 576px) {
        nav > .container {
            width: 100%;
        }
    }
    </style>
        <style>
    .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
    </style>


</head>

<body>

    <!-- Page Content -->
    <div class="container">
    <script>
function showLoanDetails(data)
{

if (window.XMLHttpRequest)
{// code for IE7+, Firefox, Chrome, Opera, Safari
xmlhttp=new XMLHttpRequest();
}
else
{// code for IE6, IE5
xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
}



xmlhttp.onreadystatechange=function()
{
if (xmlhttp.readyState==4 && xmlhttp.status==200)
{
document.getElementById("loandetails").innerHTML=xmlhttp.responseText;
}
}
//alert(data);
xmlhttp.open("GET","show_group_ajax.php?loan_details="+data,true);
xmlhttp.send();
}
</script>
        <!-- Page Heading/Breadcrumbs -->
        <h5 class="mt-4 mb-3">Apply For Leave</h5>

        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="Guardian/index.php">Home</a>
            </li>
        </ol>
            <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
        else if($msg){?><div class="succWrap"><strong>MESSAGE</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
        <!-- Content Row -->
        <form name="donar" method="post">



<div class="col-lg-4 mb-4">

<div><input type="hidden" readonly="true" name="sender"  value="<?php  echo $r1['EMPLOYEE_ID'];  ?>" class="form-control" required></div>
</div>
<div class="col-lg-4 mb-4">
<div class="font-bold">Leave Information</div>
<div><textarea rows="6"  class="form-control" name="leavedescription"></textarea></div>
</div>
<div class="col-lg-4 mb-4">
<div class="font-italic">Starting Date<span style="color:red">*</span></div>
<div><input type="date" name="startingdate" min="<?php echo date('Y-m-d'); ?>"  class="form-control"></div><br>
                              </div>
                              <script>
                    function loanamount()
                    {
                    var original=document.getElementById("amount").value;
                    var day=document.getElementById("days").value;


                    var total=(Number(original)*Number(day))/1;



                    document.getElementById("totalpaid").value=total;


                    }
                </script>
                
                <div class="col-lg-4 mb-4">
<div class="font-italic">Number of days<span style="color:red">*</span></div>
                     
                      <select onchange="loanamount()" name="days" id="days" class="form-control" required>
                          <option value="">Select </option>
                          <?php
                              for($i=1;$i<=20;$i++)
                              {
                              echo "<option value='".$i."'>".$i."</option>";
                              }
                           ?>
                      </select>
                      </div>
       

<div class="col-lg-4 mb-4">
<div><input type="submit" name="submit" class="btn btn-primary" value="submit" style="cursor:pointer"></div>
</div>




        <!-- /.row -->
</form>   
        <!-- /.row -->
</div>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/tether/tether.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

</body>

</html>
