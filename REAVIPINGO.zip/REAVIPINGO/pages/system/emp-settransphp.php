<?php
    include('configall.php');
   

$trans_allow=$_POST["trans_allow"];
$JOB_ID=$_POST["JOB_ID"];
$sql="UPDATE `employee` SET `trans_allow` = '$trans_allow' WHERE `JOB_ID` ='$JOB_ID';";
    $test=mysqli_query($connection,$sql);
if($test)
{
    header('Location:../hr-index.php');
    
}
else{
    echo'Failed to update trans_allow update';
}





?>