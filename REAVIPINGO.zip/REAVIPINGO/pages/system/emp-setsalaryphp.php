<?php
    include('configall.php');
   

$SALARY=$_POST["SALARY"];
$JOB_ID=$_POST["JOB_ID"];
$sql="UPDATE `employee` SET `SALARY` = '$SALARY' WHERE `JOB_ID` ='$JOB_ID';";
    $test=mysqli_query($connection,$sql);
if($test)
{
    header('Location:../hr-index.php');
    
}
else{
    echo'Failed to update SALARY update';
}





?>