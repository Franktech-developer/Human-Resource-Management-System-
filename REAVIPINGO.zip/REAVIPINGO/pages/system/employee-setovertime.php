<?php
include('includes/connection.php');
session_start();

$q1=mysqli_query($conn,'select * from employee where EMPLOYEE_ID="$EMPLOYEE_ID"');
$r1=mysqli_fetch_assoc($q1);

error_reporting(0);
include('includes/config.php');
if(isset($_POST['submit']))
  {
$message=$_POST['message'];
$sender=$_POST['sender'];
$receiver=$_POST['receiver'];
$status=unread;

$sql="INSERT INTO notice(message,sender,receiver,status) VALUES(:message,:sender,:receiver,:status)";
$query = $dbh->prepare($sql);
$query->bindParam(':message',$message,PDO::PARAM_STR);
$query->bindParam(':sender',$sender,PDO::PARAM_STR);
$query->bindParam(':receiver',$receiver,PDO::PARAM_STR);
$query->bindParam(':status',$status,PDO::PARAM_STR);

$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$msg=" Message send Successfully.... ";
}
else 
{
$error="Something went wrong. Please try again";
}


  }

?>
<!DOCTYPE html>
<html lang="en">
<title>absent</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/w3.css">
<link rel="stylesheet" href="css/font.css">
<style>
body,h1,h2,h3,h4,h5 {font-family: "Poppins", sans-serif}
body {font-size:16px;}
.w3-half img{margin-bottom:-6px;margin-top:16px;opacity:0.8;cursor:pointer}
.w3-half img:hover{opacity:1}
</style>
<body>

<!-- Top menu on small screens -->
<header class="w3-container w3-top w3-hide-large w3-blue w3-xlarge w3-padding">
  <span>Compute Overtime</span>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
  <div class="w3-main" style="margin-left:;margin-right:-10px;margin-top: -5px;margin-bottom: 0px">

  <!-- Header -->
      
  <div class="w3-container" style="padding: 200px 50px 70px">
      
      
      <form class="w3-container" action="setovertimedays.php" method="post">
          
                
                  <label>Select Employee</label>
                  <select name="EMPLOYEE_ID" onchange="showLoanDetails(this.value)" class="form-control" required>
                              <option value="">Select Employee </option>
                              <?php
                              $q1=mysqli_query($conn,"SELECT * from employee");
                              while($r1=mysqli_fetch_assoc($q1))
                              {
                              echo "<option value='".$r1['EMPLOYEE_ID']."'>".$r1['FIRST_NAME']."  ".$r1['LAST_NAME']."</option>";
                              }
                              ?>
                              </select>
                <p>
                     <label>Overtime ( in Hours )</label>
                      <input class="w3-input w3-light-grey w3-animate-input" type="number" name="overtime"></p>
                <input type="submit" value="submit" class="w3-input w3-green w3-round-xxlarge w3-animate-input w3-hover-blue">
                     
       
                 
               
            </form>
      
      
      
      </div>
   
      
          
  </div>

<!-- W3.CSS Container -->
<div class="w3-dark-grey w3-container w3-padding-32" style="margin-top:75px;padding-right:58px"><a href="../supervisor-index.php">Back</a></div>

<script>
// Script to open and close sidebar
function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("myOverlay").style.display = "block";
}
 
function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("myOverlay").style.display = "none";
}

// Modal Image Gallery
function onClick(element) {
  document.getElementById("img01").src = element.src;
  document.getElementById("modal01").style.display = "block";
  var captionText = document.getElementById("caption");
  captionText.innerHTML = element.alt;
}
</script>

</body>
</html>
