<?php
    include('configall.php');
   

$leave_allow=$_POST["leave_allow"];
$JOB_ID=$_POST["JOB_ID"];
$sql="UPDATE `employee` SET `leave_allow` = '$leave_allow' WHERE `JOB_ID` ='$JOB_ID';";
    $test=mysqli_query($connection,$sql);
if($test)
{
    header('Location:../hr-index.php');
    
}
else{
    echo'Failed to update leave_allow update';
}





?>