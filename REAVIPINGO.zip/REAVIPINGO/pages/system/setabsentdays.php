<?php
    include('configall.php');
   

$absence=$_POST["absence"];
$EMPLOYEE_ID=$_POST["EMPLOYEE_ID"];
$sql="UPDATE `employee` SET `absence` = '$absence' WHERE `EMPLOYEE_ID` ='$EMPLOYEE_ID';";
    $test=mysqli_query($connection,$sql);
if($test)
{
    header('Location:../supervisor-index.php');
    
}
else{
    echo'Failed to update absence update';
}





?>