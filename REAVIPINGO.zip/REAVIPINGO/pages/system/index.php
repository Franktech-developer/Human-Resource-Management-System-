<!doctype html>
<html>
       <head>
	        <meta charset="utf-8">
	        <title>Welcome to homepage</title>
			<link rel="stylesheet" href="style.css">
	   </head>
	   <body>
	   
	        <div class="loginbox">
			    <h3>Log in to here</h3>
			    <form method="post" action="newfile.php">
				     <p>Username</p>
					 <input type="text" name="username" placeholder="admin">
					 <p>Password</p>
					 <input type="password" name="password" placeholder="*****">
					 <input type="submit" name="submit" value="Submit">
				</form>
			</div>
	   </body>
</html>