<?php
    include('configall.php');
   

$leave_allow=$_POST["leave_allow"];
$EMPLOYEE_ID=$_POST["EMPLOYEE_ID"];
$sql="UPDATE `employee` SET `leave_allow` = '$leave_allow' WHERE `EMPLOYEE_ID` ='$EMPLOYEE_ID';";
    $test=mysqli_query($connection,$sql);
if($test)
{
    header('Location:../supervisor-index.php');
    
}
else{
    echo'Failed to update leave_allow update';
}





?>