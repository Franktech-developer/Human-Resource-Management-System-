<?php
 include('configall.php');

$nssf=0;
$medi_allow=0;
$trans_allow=0;
$house_allow=0;
$month=$_POST["month"];
$year=$_POST["year"];
$empid=$_POST["empid"];
$total=0;
       $sql="SELECT EMPLOYEE_ID,FIRST_NAME,LAST_NAME,b_accno,absence,overtime,house_allow,leave_allow,trans_allow,SALARY FROM `employee`WHERE EMPLOYEE_ID=$empid;";
       $result=mysqli_query($connection,$sql);
       $row=mysqli_fetch_array($result);
       
     $name=$row['FIRST_NAME'];
     $lname=$row['LAST_NAME'];
     $basic=$row['SALARY'];
     $leave_allow=$row['leave_allow'];
     $trans_allow=$row['trans_allow'];
     $absence=$row['absence'];
     $overtime=$row['overtime'];
     $acc=$row['b_accno'];
     $medi_allow = 520;
     $house_allow = $row['SALARY']*0.15;
      $nssf = 300;
      $gain = $overtime*600+$row['SALARY']+$medi_allow+$leave_allow*700+$house_allow+$trans_allow;
      $cut = $absence*500+$nssf;
      $total = $gain-$cut;

$sql2="INSERT INTO `payment` (`pay_no`, `emp_id`, `name` ,`lname` ,`basic`,`accno`, `year`, `month`, `absence`, `leave_allow`, `nssf`, `overtime`, `trans_allow`, `medi_allow`, `house_allow`, `total_pay`) VALUES (NULL, '$empid','$name','$lname','$basic','$acc', '$year', '$month', '$absence*500','$leave_allow*700','$nssf', '$overtime*600', '$trans_allow', '$medi_allow', '$house_allow', '$total');";
       
       $done=mysqli_query($connection,$sql2);

     if($done)
     {
         echo "<font color='red'><b><p class='text-center '>Calculation completed successfully </b></p></font>";
         header('Location: ../hr-index.php');
         
     }
     else{
         echo 'Failed to insert payment data';
     }
 

 
 

?>