<?php
    include('configall.php');
   

$overtime=$_POST["overtime"];
$EMPLOYEE_ID=$_POST["EMPLOYEE_ID"];
$sql="UPDATE `employee` SET `overtime` = '$overtime' WHERE `EMPLOYEE_ID` ='$EMPLOYEE_ID';";
    $test=mysqli_query($connection,$sql);
if($test)
{
    header('Location:../supervisor-index.php');
    
}
else{
    echo'Failed to update overtime update';
}





?>