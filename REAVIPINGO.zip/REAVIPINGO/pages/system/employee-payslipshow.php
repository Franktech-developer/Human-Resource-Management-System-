<?php
include('configall.php');

   $month=$_POST['month'];
   $year=$_POST['year'];
   $emp_id=$_POST['emp_id'];
   if($month)
   {
       $sql="SELECT pay_no,emp_id,name,lname,accno,basic,trans_allow,medi_allow,leave_allow,absence,nssf,house_allow,overtime,date,total_pay FROM `payment` WHERE month='$month' AND emp_id='$emp_id' AND year='$year';";
       $result=mysqli_query($connection,$sql)or die( mysqli_error($connection));
      /*while($row=mysqli_fetch_array($result)) {
          echo $row['pay_no'];
    echo $row['emp_id'];

   echo $row['name'];
   echo $row['accno'];
    echo $row['total_pay'];
      }*/
   }
?>
<!DOCTYPE html>
<html lang="en">
<title>Employee Data</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/w3.css">
<link rel="stylesheet" href="css/font.css">
<style>
body,h1,h2,h3,h4,h5 {font-family: "Poppins", sans-serif}
body {font-size:16px;}
.w3-half img{margin-bottom:-6px;margin-top:16px;opacity:0.8;cursor:pointer}
.w3-half img:hover{opacity:1}
    
    table {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

    td,th {
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2;}

tr:hover {background-color: #ddd;}

th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style>
<body>
<!-- Top menu on small screens -->
<header class="w3-container w3-top w3-hide-large w3-red w3-xlarge w3-padding">

  <span>PAYROLL RECEIPT</span>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
  <div class="w3-main" style="margin-left:;margin-right:-10px;margin-top: -5px;margin-bottom: 0px">

  <!-- Header -->
      
     <br>
   <div class="w3-container">
  <h4><b>REA VIPINGO LIMITED</b></h4><p><h6>
P.O.Box 17648,<br>
Nairobi 00500<br>
Kenya<br>
Tel: (+254) 20 6007091 / 6007169<br>
Fax: (+254) 20 6007116<br>
Email: info@reavipingo.co.ke<br>
Web: www.reavipingo.com</h6></p><hr>
<table>
               
           <?php while($row=mysqli_fetch_array($result)) {?>
           <tr>
               <td><b>Receipt No:</b> <?php echo $row['pay_no']; ?></td>
               <td><b>Date:</b>   <?php echo $row['date']; ?></td>
               </tr>
               <td><b>Bank account No:</b>  <?php echo $row['accno']; ?></td>
           </tr>
               <td>
                <b>Employee Name: </b> <?php echo $row['name']; ?>   <?php echo $row['lname']; ?>
              </td></tr>
             
               <td><b>Employee Id:</b>   <?php echo $row['emp_id']; ?></td>
             
           <tr><td><b><h5>BASIC SALARY</h5></b></td><td><b>Monthly :Ksh </b>  <?php echo $row['basic']; ?></td></tr>
           <tr><td><b><h5>ALLOWANCES</h5></b></td></tr>
               <tr><td><b>Transport :Ksh </b>  <?php echo $row['trans_allow']; ?></td>
               <td><b>Medical :Ksh </b>  <?php echo $row['medi_allow']; ?></td>
               <tr><td><b>Leave :Ksh </b>  <?php echo $row['leave_allow']*700; ?></td><tr>
               <td><b>House :Ksh </b>  <?php echo $row['house_allow']; ?></td>
               <td><b>Overtime:Ksh </b>  <?php echo $row['overtime']*600; ?></td>
               <tr><td><b><h5>DEDUCTIONS</h5></b></td></tr>
               <tr><td><b>Absent :Ksh </b>  <?php echo $row['absence']*500; ?></td>
               <td><b>Nssf :ksh </b>  <?php echo $row['nssf']; ?></td></tr>
               <tr><td><b><h5>TOTAL GROSS SALARY</h5></b></td>
               <td><b>Amount :Ksh </b>  <?php echo $row['basic']+$row['trans_allow']+$row['medi_allow']+$row['leave_allow']+$row['house_allow']+$row['overtime']*600;?></td></tr>
               <tr><td><b><h5>TOTAL NET PAY</h5></b></td>
               <td><b>Total salary:Ksh </b>  <?php echo $row['total_pay']; ?></td></tr>
               
               
           </tr>
           <?php } ?>
       </table>
       <button class="btn btn-success"><a href="download-records.php"> Download Receipt</button> <br>
       
       
      </div>
      
          
  </div>


<script>
// Script to open and close sidebar
function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("myOverlay").style.display = "block";
}
 
function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("myOverlay").style.display = "none";
}

// Modal Image Gallery
function onClick(element) {
  document.getElementById("img01").src = element.src;
  document.getElementById("modal01").style.display = "block";
  var captionText = document.getElementById("caption");
  captionText.innerHTML = element.alt;
}
</script>

</body>
</html>
