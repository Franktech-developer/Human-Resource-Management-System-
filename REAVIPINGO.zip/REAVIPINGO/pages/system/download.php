<?php 
session_start();
//error_reporting(0);
session_regenerate_id(true);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
	header("Location: index.php"); //
	}
?>
<div class="card">
<div class="col-md-12"><br>
<h3 class="header-line"><font color="red">REA VIPINGO LIMITED</font></h3><hr>
<h4><b>REA VIPINGO LIMITED</b></h4><p><h6>
P.O.Box 17648,<br>
Nairobi 00500<br>
Kenya<br>
Tel: (+254) 20 6007091 / 6007169<br>
Fax: (+254) 20 6007116<br>
Email: info@reavipingo.co.ke<br>
Web: www.reavipingo.com</h6></p><hr>
                            </div>
<table  class="table table-striped  table-hover" >
									

<?php 
$filename="FOLLOW-UP REPORT RECEIPT";
$sql = "SELECT * from  payment ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{				

echo '  
<tr>  
<tr><td><b>Pay No :</b>'.$pay_no= $result->pay_no.'</td> </tr>
<tr><td><b> Employee Id :</b>'.$emp_id= $result->emp_id.'</td> </tr>
<tr><td><b>Employee First Name :</b>'.$name= $result->name.'</td> </tr>
<tr><td><b> Last Name :</b>'.$lname= $result->lname.'</td> </tr>
<tr><td><b> Nssf :</b>'.$nssf= $result->nssf.'</td> </tr>
<tr><td><b> Basic Salary:</b>'.$basic= $result->basic.'</td> </tr>
<tr><td><b> Transport :</b>'.$trans_allow= $result->trans_allow.'</td> </tr>
<tr><td><b> Account No :</b>'.$accno= $result->accno.'</td> </tr>
<tr><td><b> Year :</b>'.$year= $result->year.'</td> </tr>
<tr><td><b> Month :</b>'.$month= $result->month.'</td> </tr>
<tr><td><b> Absence  :</b>'.$absence= $result->absence.'</td> </tr>
<tr><td><b> Date:</b>'.$date= $result->date.'</td> </tr>
<tr><td><b> Leave:</b>'.$leave= $result->leave.'</td> </tr>
<tr><td><b> Overtime :</b>'.$overtime= $result->overtime.'</td> </tr>
<tr><td><b> Medical Allowance :</b>'.$medi_allow= $result->medi_allow.'</td> </tr>
<tr><td><b> House allowance :</b>'.$house_allow= $result->house_allow.'</td> </tr>
<tr><td><b> Total Pay :</b>'.$total_pay= $result->total_pay.'</td> </tr>
<tr><td><b> Status :</b>'.$status= $result->status.'</td> </tr>
</tr>  
';
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=".$filename."-report.doc");
header("Pragma: no-cache");
header("Expires: 0");
			$cnt++;
			}
	}
?>
</table>
<?php  ?>