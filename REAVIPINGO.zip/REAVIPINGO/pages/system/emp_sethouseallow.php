<?php
    include('configall.php');
   

$house_allow=$_POST["house_allow"];
$JOB_ID=$_POST["JOB_ID"];
$sql="UPDATE `employee` SET `house_allow` = '$house_allow' WHERE `JOB_ID` ='$JOB_ID';";
    $test=mysqli_query($connection,$sql);
if($test)
{
    header('Location:../hr-index.php');
    
}
else{
    echo'Failed to update house_allow update';
}





?>