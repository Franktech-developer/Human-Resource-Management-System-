    <nav class="navbar fixed-top navbar-toggleable-md navbar-inverse bg-inverse">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarExample" aria-controls="navbarExample" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="container">
        <h5><font color="white">Rea Vipingo</font></h5>
            <div class="collapse navbar-collapse" id="navbarExample">
                <ul class="navbar-nav ml-auto">
                   

                      <li class="nav-item">
                        <a class="nav-link" href="../index.php">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
