<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>REA</title>
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="../css/modern-business.css" rel="stylesheet">
    <!-- Font awesome -->




	<link rel="stylesheet" href="/rea/admin/css/style.css">
    <style>
    .navbar-toggler {
        z-index: 1;
    }

    @media (max-width: 576px) {
        nav > .container {
            width: 100%;
        }
    }
    .carousel-item.active,
    .carousel-item-next,
    .carousel-item-prev {
        display: block;
    }
    </style>

</head>

<body>

    <!-- Navigation -->
<?php include('includes/header.php');?>
<br>
<hr>
    <!-- Page Content -->
    <div class="container">
    <section class="content-header">
     <ol class="breadcrumb">
        <li><a href="logout.php"><i class="fa fa-dashboard"></i> Exit</a></li>
        <li class="active"></li>
      </ol>
    </section>

     <hr>
     
            <div class="card">



						<div class="card">

								<div class="card">

										<div class="panel panel-default">
											<div class="panel-body bk-primary text-light">
												<div class="stat-panel text-center">

												<?php
$sql6 ='SELECT * from application where email="'.$_SESSION['alogin'].'" and status="YouHaveBeenShortlisted" ';
$query6 = $dbh -> prepare($sql6);;
$query6->execute();
$results6=$query6->fetchAll(PDO::FETCH_OBJ);
$query=$query6->rowCount();
?>
													<div class="stat-panel-title text-uppercase">My Application</div>
												</div>
											</div>
											<a href="../admin/rnotify.php" class="block-anchor panel-footer text-center"> View Status &nbsp; <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>

								</div>

							</div>
                            </div>

</div>















    <!-- Footer -->

    <!-- Bootstrap core JavaScript -->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/tether/tether.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

</body>

</html>
