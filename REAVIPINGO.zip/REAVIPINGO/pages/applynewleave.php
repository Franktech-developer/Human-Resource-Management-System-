<?php
include('connection.php');
session_start();

$q1=mysqli_query($conn,'select * from users where ID="'.$_SESSION['MEMBER_ID'].'"');
$r1=mysqli_fetch_assoc($q1);

error_reporting(0);
include('config.php');
if(isset($_POST['submit']))
  {
$LOGID=$_POST['LOGID'];
$fullnames=$_POST['fullnames'];
$department=$_POST['department'];
$email=$_POST['email'];
$request=$_POST['request'];
$status=Unread;



$sql="INSERT INTO report(LOGID,fullnames,department,email,request,status) VALUES(:LOGID,:fullnames,:department,:email,:request,:status)";
$query = $dbh->prepare($sql);
$query->bindParam(':LOGID',$LOGID,PDO::PARAM_STR);
$query->bindParam(':fullnames',$fullnames,PDO::PARAM_STR);
$query->bindParam(':department',$department,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->bindParam(':request',$request,PDO::PARAM_STR);
$query->bindParam(':status',$status,PDO::PARAM_STR);

$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$msg="Your Request Has Been Received Successfully.... ";
}
else
{
$error="Something went wrong. Please try again";
}


  }

?>


<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BMC</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/modern-business.css" rel="stylesheet">
    <style>
    .navbar-toggler {
        z-index: 1;
    }

    @media (max-width: 576px) {
        nav > .container {
            width: 100%;
        }
    }
    </style>
        <style>
    .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
    </style>


</head>

<body>
    <!-- Page Content -->
    <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <h5 class="mt-4 mb-3">Make Your Request</h5>

        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="employee-index.php">Home</a>
            </li>
        </ol>
            <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php }
        else if($msg){?><div class="succWrap"><strong>MESSAGE</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
        <!-- Content Row -->
        <form name="donar" method="post">
        <div class="card">
<div class="col-lg-4 mb-4">

<div><input type="hidden" name="fullnames" readonly="true" value="<?php  echo $r1['fullnames'];  ?>" class="form-control" required></div>
</div>
<div class="col-lg-4 mb-4">

<div><input type="hidden" readonly="true" name="department"  value="<?php  echo $r1['department'];  ?>" class="form-control" required></div>
</div>
<div class="col-lg-4 mb-4">

<div><input type="hidden" readonly="true" name="LOGID"  value="<?php  echo $r1['ID'];  ?>" class="form-control" required></div>
</div>

<div class="col-lg-4 mb-4">

<div><input type="hidden" readonly="true" name="email"  value="<?php  echo $r1['email'];  ?>" class="form-control" required></div>
</div>

<div class="col-lg-4 mb-4">
<div class="font-italic">Request<span style="color:red">*</span></div>
<div><textarea rows="5"class="form-control" name="request"></textarea></div>
</div>


<div class="">
<div class="col-lg-4 mb-4">
<div><input type="submit" name="submit" class="btn btn-primary" value="submit" style="cursor:pointer"></div>
</div>




        <!-- /.row -->
</form>
        <!-- /.row -->
</div>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/tether/tether.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

</body>

</html>
