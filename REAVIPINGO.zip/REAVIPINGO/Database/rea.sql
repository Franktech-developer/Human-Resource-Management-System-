-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 09:47 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rea`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `Password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `UserName`, `email`, `Password`) VALUES
(1, 'admin@gmail.com', 'admin@gmail.com', '12345678');

-- --------------------------------------------------------

--
-- Table structure for table `allowances`
--

CREATE TABLE `allowances` (
  `id` int(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `amount` int(20) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `allowances`
--

INSERT INTO `allowances` (`id`, `type`, `amount`, `status`) VALUES
(1, 'sick leave', 200, 1);

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `id` int(11) NOT NULL,
  `fullnames` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `idno` varchar(20) DEFAULT NULL,
  `jobname` varchar(20) DEFAULT NULL,
  `coverletter` varchar(200) DEFAULT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`id`, `fullnames`, `email`, `idno`, `jobname`, `coverletter`, `status`) VALUES
(11, 'Samson koskey', 'samsonkkoskei@gmail.com', '12345678', NULL, 'Competent graduate', 'Qualified'),
(12, 'Frank', 'frankmbithi21@gmail.com', '37005863', NULL, 'I\'m a computer science graduate.', 'Qualified'),
(13, 'francis', 'francismbithi921@gmail.com', '37005863', NULL, 'I\'m a graduate ', 'Qualified'),
(14, 'Jose', 'jose@gmail.com', '37005863', NULL, 'Bachelor of science in mechanical engineering, very competent in engeerinng field and cooperative in all fields.', 'YouHaveBeenShortlisted');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `CUST_ID` int(11) NOT NULL,
  `FIRST_NAME` varchar(50) DEFAULT NULL,
  `LAST_NAME` varchar(50) DEFAULT NULL,
  `PHONE_NUMBER` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `id` int(15) NOT NULL,
  `name` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `name`, `status`) VALUES
(4, 'vv', ''),
(5, 'Finance', ''),
(6, 'Marketing department', '');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `EMPLOYEE_ID` int(11) NOT NULL,
  `FIRST_NAME` varchar(50) DEFAULT NULL,
  `LAST_NAME` varchar(50) DEFAULT NULL,
  `GENDER` varchar(50) DEFAULT NULL,
  `Address` varchar(50) NOT NULL,
  `EMAIL` varchar(100) DEFAULT NULL,
  `PHONE_NUMBER` varchar(11) DEFAULT NULL,
  `JOB_ID` int(11) DEFAULT NULL,
  `loan` int(100) NOT NULL,
  `pfund` int(100) NOT NULL,
  `absence` int(10) NOT NULL,
  `overtime` varchar(100) NOT NULL,
  `days` datetime NOT NULL DEFAULT current_timestamp(),
  `SALARY` int(50) NOT NULL,
  `house_allow` int(50) NOT NULL,
  `leave_allow` int(50) NOT NULL,
  `date` date DEFAULT NULL,
  `startingdate` datetime NOT NULL DEFAULT current_timestamp(),
  `b_accno` int(40) NOT NULL,
  `leavedescription` varchar(500) NOT NULL,
  `type` varchar(10) NOT NULL,
  `trans_allow` int(50) NOT NULL,
  `MEDICALALLOWANCE` int(10) NOT NULL,
  `REQUEST` varchar(200) NOT NULL,
  `DEPARTMENT` varchar(50) NOT NULL,
  `USERNM` varchar(100) NOT NULL,
  `PASSWRD` varchar(100) NOT NULL,
  `HIRED_DATE` varchar(50) NOT NULL DEFAULT current_timestamp(),
  `LOCATION_ID` int(11) DEFAULT NULL,
  `STATUS` varchar(50) NOT NULL,
  `leavestatus` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`EMPLOYEE_ID`, `FIRST_NAME`, `LAST_NAME`, `GENDER`, `Address`, `EMAIL`, `PHONE_NUMBER`, `JOB_ID`, `loan`, `pfund`, `absence`, `overtime`, `days`, `SALARY`, `house_allow`, `leave_allow`, `date`, `startingdate`, `b_accno`, `leavedescription`, `type`, `trans_allow`, `MEDICALALLOWANCE`, `REQUEST`, `DEPARTMENT`, `USERNM`, `PASSWRD`, `HIRED_DATE`, `LOCATION_ID`, `STATUS`, `leavestatus`) VALUES
(1, 'Supervisor', 'Supervisor', 'Male', '', 'sup@gmail.com', '09124033805', 1, 0, 0, 0, '', '2022-07-15 12:22:27', 100000, 0, 0, NULL, '2022-07-15 12:22:03', 7878, '', '', 0, 0, '', '', '', '', '0000-00-00', 113, 'Pending', ''),
(2, 'Employee', 'Employee', 'Male', '', 'jmagaso@yahoo.com', '09091245761', 2, 0, 0, 0, '', '2022-07-15 12:22:27', 80000, 2000, 20000, NULL, '2022-07-15 12:22:03', 0, '', '', 3000, 0, '', '', '', '', '2019-01-28', 156, 'Approved', ''),
(4, 'Human Manger', 'Resource', 'Male', '', 'hr@gmail.com', '1234567', 1, 0, 0, 0, '', '2022-07-15 12:22:27', 100000, 0, 0, NULL, '2022-07-15 12:22:03', 3354, '', '', 0, 0, '', '', '', '', '2022-03-06', 158, 'Approved', ''),
(5, 'aloice', 'boyani', 'Female', '', 'alice@gmail.com', '0707', 4, 0, 0, 0, '', '2022-07-15 12:22:27', 80000, 0, 0, NULL, '2022-07-15 12:22:03', 0, '', '', 3000, 0, '', '', '', '', '2022-06-24', 159, 'Approved', ''),
(41, 'Francis', 'Mbithi', 'Male', '', 'frank@gmail.com', '07015760040', 2, 0, 0, 0, '5', '2022-07-18 12:30:53', 80000, 2000, 4, NULL, '2022-07-18 12:30:53', 6666666, '', '', 3000, 0, '', '', '', '', '2022-07-18', 169, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `idno` int(11) DEFAULT NULL,
  `fullnames` varchar(40) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `department` varchar(20) DEFAULT NULL,
  `salary` varchar(20) DEFAULT NULL,
  `salarystatus` varchar(20) NOT NULL,
  `amount` varchar(20) NOT NULL,
  `days` varchar(20) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `totalamount` varchar(20) NOT NULL,
  `leavee` varchar(40) NOT NULL,
  `leaveestatus` varchar(20) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `STATUS` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedback_id` int(10) NOT NULL,
  `message` varchar(1000) DEFAULT NULL,
  `frm` varchar(20) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `hrmessage`
--

CREATE TABLE `hrmessage` (
  `id` int(11) NOT NULL,
  `message` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hrmessage`
--

INSERT INTO `hrmessage` (`id`, `message`) VALUES
(1, 'you must no matter what'),
(2, 'there is a lion walking around\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE `job` (
  `JOB_ID` int(11) NOT NULL,
  `JOB_TITLE` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`JOB_ID`, `JOB_TITLE`) VALUES
(1, 'Admin'),
(2, 'Employee'),
(3, 'Hr'),
(4, 'Supervisor'),
(5, 'Finance');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` int(11) NOT NULL,
  `jobname` varchar(20) DEFAULT NULL,
  `description` varchar(500) NOT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `jobname`, `description`, `status`) VALUES
(5, 'engineering ', 'a graduate ', 'Available'),
(6, 'Cook', 'A form four graduate', 'NotAvailable');

-- --------------------------------------------------------

--
-- Table structure for table `leavee`
--

CREATE TABLE `leavee` (
  `id` int(11) NOT NULL,
  `LOGID` int(50) NOT NULL,
  `fullnames` varchar(20) DEFAULT NULL,
  `startingdate` datetime NOT NULL DEFAULT current_timestamp(),
  `days` varchar(50) NOT NULL,
  `department` varchar(20) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `request` varchar(100) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leavee`
--

INSERT INTO `leavee` (`id`, `LOGID`, `fullnames`, `startingdate`, `days`, `department`, `email`, `request`, `status`) VALUES
(8, 16, '', '2022-07-17 17:57:07', '', '', '', 'hhshs', 'OnLeave');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `LOCATION_ID` int(11) NOT NULL,
  `PROVINCE` varchar(100) DEFAULT NULL,
  `CITY` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`LOCATION_ID`, `PROVINCE`, `CITY`) VALUES
(111, 'Nigeria', 'Mombasa'),
(112, 'Negros Occidental', 'Bacolod City'),
(113, 'Negros Occidental', 'Binalbagan'),
(114, 'Negros Occidental', 'Himamaylan'),
(115, 'Negros Oriental', 'Dumaguette City'),
(116, 'Negros Occidental', 'Isabella'),
(126, 'Negros Occidental', 'Binalbagan'),
(130, 'Cebu', 'Bogo City'),
(131, 'Negros Occidental', 'Himamaylan'),
(132, 'Negros', 'Jupiter'),
(133, 'Aincrad', 'Floor 91'),
(134, 'negros', 'binalbagan'),
(135, 'hehe', 'tehee'),
(136, 'PLANET YEKOK', 'KOKEY'),
(137, 'Camiguin', 'Catarman'),
(138, 'Camiguin', 'Catarman'),
(139, 'Negros Occidental', 'Binalbagan'),
(140, 'Batangas', 'Lemery'),
(141, 'Capiz', 'Panay'),
(142, 'Camarines Norte', 'Labo'),
(143, 'Camarines Norte', 'Labo'),
(144, 'Camarines Norte', 'Labo'),
(145, 'Camarines Norte', 'Labo'),
(146, 'Capiz', 'Pilar'),
(147, 'Negros Occidental', 'Moises Padilla'),
(148, 'a', 'a'),
(149, '1', '1'),
(150, 'Negros Occidental', 'Himamaylan'),
(151, 'Masbate', 'Mandaon'),
(152, 'Aklanas', 'Madalagsasa'),
(153, 'Batangas', 'Mabini'),
(154, 'Bataan', 'Morong'),
(155, 'Capiz', 'Pillar'),
(156, 'Negros Occidental', 'Bacolod'),
(157, 'Camarines Norte', 'Labo'),
(158, 'Negros Occidental', 'Binalbagan'),
(159, 'Ilocos Norte', 'Laoag'),
(160, 'Bohol', 'Sevilla'),
(161, 'Cagayan', 'Pamplona'),
(162, 'Apayao', 'Flora'),
(163, 'Bukidnon', 'Manolo Fortich'),
(164, 'Basilan', 'Maluso'),
(165, 'Bohol', 'Mabini'),
(166, 'Benguet', 'Sablan'),
(167, 'Camarines Norte', 'Basud'),
(168, 'Aurora', 'Dinalungan'),
(169, 'Tarlac', 'San Manuel'),
(170, 'Cebu', 'Badian'),
(171, 'Albay', 'Ligao');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `fullnames` varchar(40) DEFAULT NULL,
  `department` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `reason` varchar(400) NOT NULL,
  `email` varchar(20) DEFAULT NULL,
  `absent` varchar(200) NOT NULL,
  `LOGID` int(50) NOT NULL,
  `date` varchar(20) DEFAULT NULL,
  `cdate` varchar(20) DEFAULT NULL,
  `comment` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `fullnames`, `department`, `phone`, `reason`, `email`, `absent`, `LOGID`, `date`, `cdate`, `comment`) VALUES
(45, '', '', '', '', NULL, '', 41, '2022-07-18', '2022-07-18 12:34:52', 'Signed'),
(46, '', '', '', '', NULL, '', 42, '2022-07-20', '2022-07-20 03:51:24', 'Signed');

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE `notice` (
  `id` int(11) NOT NULL,
  `message` varchar(200) DEFAULT NULL,
  `sender` varchar(50) DEFAULT NULL,
  `receiver` varchar(40) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`id`, `message`, `sender`, `receiver`, `status`) VALUES
(12, 'hey', 'Manager', 'staff', 'staff'),
(14, 'Let\'s meet for a meeting ', 'Manager', 'staff', 'staff'),
(15, 'hey', 'Manager', 'employess', 'staff'),
(16, 'hey', 'Manager', 'employess', 'staff'),
(17, 'hey', 'Manager', 'employess', 'staff'),
(18, 'tomorrow we have a meeting ', 'Manager', 'employess', 'staff');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `pay_no` int(11) NOT NULL,
  `emp_id` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `nssf` int(10) NOT NULL,
  `basic` int(100) NOT NULL,
  `trans_allow` int(10) NOT NULL,
  `accno` int(20) NOT NULL,
  `year` int(11) NOT NULL,
  `month` varchar(50) NOT NULL,
  `absence` int(11) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `leave_allow` float NOT NULL,
  `pfund_cut` float NOT NULL,
  `overtime` float NOT NULL,
  `season_bonus` float NOT NULL,
  `other_bonus` float NOT NULL,
  `medi_allow` float NOT NULL,
  `house_allow` float NOT NULL,
  `total_pay` float NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `PRODUCT_ID` int(11) NOT NULL,
  `PRODUCT_CODE` varchar(20) NOT NULL,
  `NAME` varchar(50) DEFAULT NULL,
  `DESCRIPTION` varchar(250) NOT NULL,
  `QTY_STOCK` int(50) DEFAULT NULL,
  `ON_HAND` int(250) NOT NULL,
  `PRICE` int(50) DEFAULT NULL,
  `CATEGORY_ID` int(11) DEFAULT NULL,
  `SUPPLIER_ID` int(11) DEFAULT NULL,
  `DATE_STOCK_IN` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`PRODUCT_ID`, `PRODUCT_CODE`, `NAME`, `DESCRIPTION`, `QTY_STOCK`, `ON_HAND`, `PRICE`, `CATEGORY_ID`, `SUPPLIER_ID`, `DATE_STOCK_IN`) VALUES
(1, '20191001', 'Lenovo ideapad 20059', 'Windows 8', 1, 1, 32999, 7, 15, '2019-03-02'),
(3, '20191003', 'Predator Helios 300 Gaming Laptop', 'Windows 10 Home\r\nIntelÂ® Coreâ„¢ i7-8750H processor Hexa-core 2.20 GHz\r\n15.6\" Full HD (1920 x 1080) ', 1, 1, 77850, 7, 15, '2019-03-02'),
(4, '20191002', 'Newmen E120', 'hehe', 1, 1, 550, 0, 11, '2019-03-02'),
(5, '20191002', 'Newmen E120', 'hehe', 1, 1, 550, 0, 15, '2019-03-03'),
(6, '20191002', 'Newmen E120', 'hehe', 1, 1, 550, 0, 11, '2019-03-04'),
(8, '20191002', 'Newmen E120', 'hehe', 1, 1, 550, 0, 11, '2019-03-05'),
(9, '20191002', 'Newmen E120', 'hehe', 1, 1, 550, 0, 11, '2019-03-04'),
(10, '20191004', 'Fantech EG1', 'BEST FOR MOBILE PHONE GAMERS\r\nSPEAKER:10mm\r\nIMPEDANCE: 18+-15%\r\nFREQUENCY RESPONSE: 20 TO 20khz\r\nMICROPHONE : OMNI DIRECTIONAL\r\nJACK: AUDIO+MICROPHONE\r\nCOMBINED JACK 3.5 WIRE\r\nWIRE LENGTH: 1.3M\r\nWhat in inside:-1 pcs Female 3.5mm to Audio and\r\nmicrop', 1, 1, 859, 6, 13, '2019-03-06'),
(11, '20191004', 'Fantech EG1', 'a', 1, 1, 895, 6, 13, '2019-03-01'),
(12, '20191004', 'Fantech EG1', 'a', 1, 1, 895, 6, 13, '2019-03-01'),
(13, '20191004', 'Fantech EG1', 'a', 1, 1, 895, 6, 13, '2019-03-01'),
(14, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(15, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(16, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(17, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(18, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(19, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(20, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(21, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(22, '20191001', 'Lenovo ideapad 20059', 'hehe', 1, 1, 32999, 7, 12, '2019-03-11'),
(23, '20191001', 'Lenovo ideapad 20059', 'hehe', 1, 1, 32999, 7, 12, '2019-03-11'),
(24, '20191001', 'Lenovo ideapad 20059', 'hehe', 1, 1, 32999, 7, 12, '2019-03-11'),
(25, '20191001', 'Lenovo ideapad 20059', 'hehe', 1, 1, 32999, 7, 12, '2019-03-11'),
(26, '20191001', 'Lenovo ideapad 20059', 'hehe', 1, 1, 32999, 7, 12, '2019-03-11'),
(27, '20191005', 'A4tech OP-720', 'normal mouse', 1, 1, 289, 1, 16, '2019-03-13');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `id` int(11) NOT NULL,
  `LOGID` int(50) NOT NULL,
  `fullnames` varchar(20) DEFAULT NULL,
  `department` varchar(20) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `request` varchar(100) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`id`, `LOGID`, `fullnames`, `department`, `email`, `request`, `status`) VALUES
(9, 18, '', '', '', 'in need of some resources ', 'Unread');

-- --------------------------------------------------------

--
-- Table structure for table `requestleave`
--

CREATE TABLE `requestleave` (
  `id` int(11) NOT NULL,
  `LOGID` int(50) NOT NULL,
  `leavedescription` varchar(1000) DEFAULT NULL,
  `startingdate` datetime DEFAULT current_timestamp(),
  `days` int(10) DEFAULT NULL,
  `request` varchar(100) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `requestleave`
--

INSERT INTO `requestleave` (`id`, `LOGID`, `leavedescription`, `startingdate`, `days`, `request`, `status`) VALUES
(15, 16, '', '2022-07-30 00:00:00', 10, 'want to go for a vacation with my family', 'OnLeave'),
(16, 18, '', '2022-07-30 00:00:00', 10, 'Vacation ', 'Completed'),
(17, 19, '', '2022-07-20 00:00:00', 10, 'Sickness ', 'Completed'),
(18, 18, '', '2022-07-25 00:00:00', 3, 'Unwell ', 'Received');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `id` int(11) NOT NULL,
  `message` varchar(200) DEFAULT NULL,
  `sender` varchar(50) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `receiver` varchar(40) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(40) NOT NULL,
  `first_name` varchar(40) NOT NULL,
  `last_name` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `phone` int(40) NOT NULL,
  `gender` varchar(40) NOT NULL,
  `country` varchar(40) NOT NULL,
  `position` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `status` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `first_name`, `last_name`, `email`, `phone`, `gender`, `country`, `position`, `password`, `status`) VALUES
(7, 'peter', 'teacher', 'hr@gmail.com', 786567587, 'Male', 'Kenya', 'H R', '12345', 'pending'),
(8, 'catherine', 'cherin', 'super@gmail.com', 745572298, 'Female', 'Kenya', 'Supervisor', '12345', 'approved'),
(9, 'kariuki', 'karaka', 'kariuki@gmail.com', 2147483647, 'Male', 'Kenya', 'Finance Officer', '12345', 'approved'),
(10, 'Samson', 'Koskei', 'admin@gmail.com', 701576004, 'Male', 'Benin', 'Supervisor', '12345678', 'approved'),
(11, 'Samson', 'Koskei', 'admin@gmail.com', 701576004, 'Male', 'Belgium', 'H R', '12345678', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactusquery`
--

CREATE TABLE `tblcontactusquery` (
  `id` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `EmailId` varchar(120) DEFAULT NULL,
  `ContactNumber` char(11) DEFAULT NULL,
  `Message` longtext DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

CREATE TABLE `tblpages` (
  `id` int(11) NOT NULL,
  `PageName` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT '',
  `detail` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpages`
--

INSERT INTO `tblpages` (`id`, `PageName`, `type`, `detail`) VALUES
(3, 'About Us ', 'aboutus', '<span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; text-align: justify;\">Badilisha Maisha Center is a Rescue Center located in Eldoret, established in 2015.Being one of the charity organization in Kenya, its main objective is provide academic financial support to the needy children and in so doing eradicate poverty and illiteracy . Every year they conduct interviews and select only seven kids to support in their program.\r\nAfter every selection, those kids successful are taken through mentorship program for eight months at the organization. During this moment the kids are inspired with courage, hope and optimism about life. They are also taught the importance of education and how it can transform their lives and that of their families. On the completion of eight months they are taken back to their families with full sponsorship of their education but from the school of their choice and their parents.\r\nThe organization has a follow-up program that does regular visits to the kids, both at home and school to check on their academic progress and general life style. During this period the kids are able to share about their healthy, dreams, ambitions and hope with social worker doing the follow-up. \r\n</span>');

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `TYPE_ID` int(11) NOT NULL,
  `TYPE` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`TYPE_ID`, `TYPE`) VALUES
(1, 'Admin'),
(2, 'Employee'),
(3, 'Hr'),
(4, 'Supervisor'),
(5, 'Finance');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `EMPLOYEE_ID` int(11) DEFAULT NULL,
  `USERNAME` varchar(50) DEFAULT NULL,
  `PASSWORD` varchar(50) DEFAULT NULL,
  `TYPE_ID` int(11) DEFAULT NULL,
  `STATUS` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `EMPLOYEE_ID`, `USERNAME`, `PASSWORD`, `TYPE_ID`, `STATUS`) VALUES
(1, 1, 'supervisor', '12345678', 4, ''),
(7, 2, 'employee', '12345678', 2, ''),
(9, 4, 'hr', '12345678', 3, ''),
(10, 5, 'finance', '12345678', 5, ''),
(14, 5, 'finance', '12345678', 5, ''),
(18, 41, 'sam', '12345678', 2, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `allowances`
--
ALTER TABLE `allowances`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`CUST_ID`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`EMPLOYEE_ID`),
  ADD UNIQUE KEY `EMPLOYEE_ID` (`EMPLOYEE_ID`),
  ADD UNIQUE KEY `PHONE_NUMBER` (`PHONE_NUMBER`),
  ADD KEY `LOCATION_ID` (`LOCATION_ID`),
  ADD KEY `JOB_ID` (`JOB_ID`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedback_id`);

--
-- Indexes for table `hrmessage`
--
ALTER TABLE `hrmessage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job`
--
ALTER TABLE `job`
  ADD PRIMARY KEY (`JOB_ID`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leavee`
--
ALTER TABLE `leavee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`LOCATION_ID`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`pay_no`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`PRODUCT_ID`),
  ADD KEY `CATEGORY_ID` (`CATEGORY_ID`),
  ADD KEY `SUPPLIER_ID` (`SUPPLIER_ID`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `requestleave`
--
ALTER TABLE `requestleave`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontactusquery`
--
ALTER TABLE `tblcontactusquery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpages`
--
ALTER TABLE `tblpages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`TYPE_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `TYPE_ID` (`TYPE_ID`),
  ADD KEY `EMPLOYEE_ID` (`EMPLOYEE_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `allowances`
--
ALTER TABLE `allowances`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `application`
--
ALTER TABLE `application`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `CUST_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `EMPLOYEE_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedback_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrmessage`
--
ALTER TABLE `hrmessage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `job`
--
ALTER TABLE `job`
  MODIFY `JOB_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `leavee`
--
ALTER TABLE `leavee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `LOCATION_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=172;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `notice`
--
ALTER TABLE `notice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `pay_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `PRODUCT_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `requestleave`
--
ALTER TABLE `requestleave`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tblcontactusquery`
--
ALTER TABLE `tblcontactusquery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tblpages`
--
ALTER TABLE `tblpages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
